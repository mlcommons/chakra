Reference outputs for tests/test_pipeline_outputs.py.

Recorded with Chakra 4c0ba11 (the et_replay port, AST-identical to PARAM et_replay 7b19f58), whose
outputs equal main at 2d76d5b with PARAM installed. The linked trace was also produced with the real PARAM et_replay:
identical.

Inputs: tests/data/simple_onerank_traces.tar.gz (gpu/host.0.json, gpu/device.0.json) and
tests/data/1.0.2-chakra.0.0.4.tgz.

  simple_onerank/linked.0.json   chakra_trace_link --rank 0 on gpu/host.0.json and gpu/device.0.json
  simple_onerank/linked.0.et     chakra_converter PyTorch on linked.0.json
  simple_onerank/host.0.et       chakra_converter PyTorch on gpu/host.0.json
  1.0.2-chakra.0.0.4/host.et     chakra_converter PyTorch on 1.0.2-chakra.0.0.4.json

The tests compare the outputs of the current code with these. They are never regenerated to make a test pass: a
deliberate change of output regenerates them with
  python tests/test_pipeline_outputs.py --regenerate
and the pull request says why.

SHA-256:
2c077ff5e90b6ede056e5e67ff5f02daab8150cec46f6fda2a5d1d666864c05d  simple_onerank/linked.0.json
b904f2141750170971824a07586379f7f0e9a1369fd3f3922be54b2d3ca8d66c  simple_onerank/linked.0.et
e060b969a8c09cf3ef476f636e4337d851ec19e4e7c26e21dad21dfba7d4690e  simple_onerank/host.0.et
e643cac20713714a33e784f9d44bd11e998b28398932913ae3a4d85c1c1342cc  1.0.2-chakra.0.0.4/host.et
